library(igraph)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
load("L2bootcamp.Rdata")


################
# TASK 1:
# - plot it with various layouts: layout_with_kk,layout_with_fr, layout_in_circle, layout_with..... (you choose :)
################

plot(nets
     ,asp=FALSE,edge.arrow.size=0.2)

################
# TASK 2:
# - compute various centralities: degree, closeness, betwenness, hub/authority
# - plot vertex sizes according to their centrality
# - plot edge width using weights
# - filter out nodes with no outgoing links
# - discuss social roles of the nodes (Where is Michal?)
################

################
# TASK 3:
# - can you find social motiffs (e.g., cliques, triangles, lone wolves, communities) and interpret them?
# - find community detection algorithm obtaining highest modularity value
# - check how edge weights affect the above results (see,e.g., help(cluster_louvain))
################


#Levels
all=read.csv("all_good.csv", header=TRUE)



# Age? 
#   1.	under 25; 
# 2. 26-35; 
# 3.	over 36; 
# 4.	prefer not to say.
# Gender? 
#   1.	male; 
# 2.	female; 
# 9.	prefer not to say.
# 
# Educational attainment: 
#   1.	BA/BSc or equivalent; 
# 2.	MA/MSc or equivalent; 
# 3.	PhD or above; 
# 9.	prefer not to say.
# 
# Would you perceive your background to be: 
#   1.	linguistics; 
# 2.	literature; 
# 3.	language education; 
# 4.	other; 
# 9.	prefer not to say.
# 
# Have you been familiar with networks before? 
#   1.	yes; 
# 2.	no.

################
# TASK 4:
# - can you run correlation analysis (or linear models) linking metrics with centrality (as degree)
################


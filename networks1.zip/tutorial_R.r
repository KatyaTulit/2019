###
### From crashR.R demo
###

# Some handy RStudio (Windows) keyboard shortcuts for starters:
# ctrl+enter: for run selected lines from source script
# ctrl+1: go to console
# ctrl+2: go to source
# alt+-: write " <- "
# ctrl+shift+C: comment/uncomment line

### R objects, (real) numbers
a <- 3
a
b <- 4
b
a+b

### Case sensitive
A <- 16
a
A

### Vector objects
a <- c(1,2,3,4,5,6,7,8,9,10)
a
b <- 1:100
b
a[1]
b[1:5]
b[c(1,2,47)]
a[1] <- 10
a
a[1:4] <- 2
a
b[seq(2,10,by=2)+1]


### Vector arithmetic
a * 2 + 1

### Matrices
M <- matrix(1:20, 10, 2)
M
M[1,1]
M[1,]
M[,1]
M[1:5,2]

### Functions
ls
mean(a)
remove(A)
sd
c

### Classes
class(2)
class(1:10)
class(sd)

### Getting help
# ?sd
# ??"standard deviation"
# RSiteSearch("network betweenness")

### Character vectors
char.vec <- c("this", "is", "a", "vector", "of", "characters")
char_vec <- char.vec
char.vec[1]

### Named vectors
age <- c(45, 36, 65, 21, 52, 19)
age
names(age) <- c("Alice", "Bob", "Cecil", "David", "Eve", "Fiona")
age
age["Bob"]
age[c("Eve", "David", "David")]

### Indexing with logical vectors
age[c(FALSE, TRUE, FALSE, TRUE, FALSE, TRUE)]
names(age)[ age>40 ]
age > 40

### Lists
l <- list(1:10, "Hello!", diag(5))
l
l[[1]]
l[2:3]
l2 <- list(A=1:10, H="Hello!", M=diag(5))
l2
l2$A
l2$M

### Factors
countries <- c("SUI", "USA", "GBR", "GER", "SUI",
               "SUI", "GBR", "GER", "FRA", "GER")
countries
fcountries <- factor(countries)
fcountries
levels(fcountries)

### Data frames
survey <- data.frame(row.names=c("Alice", "Bob", "Cecil", "David", "Eve"),
                     Sex=c("F","M","F","F","F"),
                     Age=c(45,36,65,21,52),
                     Country=c("SUI", "USA", "SUI", "GBR", "USA"),
                     Married=c(TRUE, FALSE, FALSE, TRUE, TRUE),
                     Salary=c(70, 65, 200, 45, 100))
survey
survey$Sex
plot(survey$Age, survey$Salary)

AS.model <- lm(Salary ~ Age, data=survey)
AS.model
summary(AS.model)
abline(AS.model)

tapply(survey$Salary, survey$Country, mean)
